#
#	Check we have a few required directories, that might not hve been created because they are empty.
#
dir=`dirname $0`
mkdir -p ${dir}/../tomcat/logs
mkdir -p ${dir}/../tomcat/temp
mkdir -p ${dir}/../site-conf

exit 0
